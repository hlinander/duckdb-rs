#include "src/function/scalar/string/caseconvert.cpp"

#include "src/function/scalar/string/concat.cpp"

#include "src/function/scalar/string/concat_ws.cpp"

#include "src/function/scalar/string/length.cpp"

#include "src/function/scalar/string/like.cpp"

#include "src/function/scalar/string/nfc_normalize.cpp"

#include "src/function/scalar/string/regexp.cpp"

#include "src/function/scalar/string/substring.cpp"

#include "src/function/scalar/string/prefix.cpp"

#include "src/function/scalar/string/strip_accents.cpp"

#include "src/function/scalar/string/suffix.cpp"

#include "src/function/scalar/string/contains.cpp"

